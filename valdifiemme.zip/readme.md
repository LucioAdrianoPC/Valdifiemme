Restaurant OnePage HTML5 restaurant Template
========
<img src="https://cloud.githubusercontent.com/assets/10640964/8260476/cfaac5a0-16e5-11e5-8fc8-e9d3f46796e1.jpg" />

<a href="http://themefisher.com/download/restaurant">Live Preview</a>
========
Restaurant is a html5 one page landing page template developed based on twitter bootstrap 3.2. It can be used as show case for your restaurant website .We organized file structure and descriptive comments on codes will enable your showcase easy to maintain.