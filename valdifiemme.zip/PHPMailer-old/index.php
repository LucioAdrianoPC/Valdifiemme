<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<meta http-equiv="refresh" content=1;url="https://www.saolourenco.mg.gov.br">	
</head>

<body>
<h1>Você será direcionado para página principal da Prefeitura de São Lourenço - MG</h1>	
</body>
</html>